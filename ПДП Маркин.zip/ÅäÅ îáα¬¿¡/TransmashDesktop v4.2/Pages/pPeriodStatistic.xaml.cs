﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для pPeriodStatistic.xaml
    /// </summary>
    public partial class pPeriodStatistic : Page
    {
        public pPeriodStatistic()
        {
            InitializeComponent();
            dpFrom.DisplayDateStart = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1).Min(c => c.filing_date);
            dpFrom.DisplayDateEnd = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1).Max(c => c.filing_date);
            dpTo.DisplayDateStart = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1).Min(c => c.filing_date);
            dpTo.DisplayDateEnd = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1).Max(c => c.filing_date);
            DatePeriod();
        }

        private void dpFrom_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DatePeriod();
        }

        private void DatePeriod()
        {
            if (dpFrom.SelectedDate == null && dpTo.SelectedDate == null)
            {
                Update(ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1).ToList());
            }
            if (dpFrom.SelectedDate != null && dpTo.SelectedDate == null)
            {
                Update(ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && c.filing_date >= dpFrom.SelectedDate).ToList());

            }
            if (dpFrom.SelectedDate == null && dpTo.SelectedDate != null)
            {
                Update(ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && c.filing_date <= dpTo.SelectedDate).ToList());

            }
            if (dpFrom.SelectedDate != null && dpTo.SelectedDate != null)
            {
                Update(ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && c.filing_date >= dpFrom.SelectedDate && c.filing_date <= dpTo.SelectedDate).ToList());
            }
        }

        private void Update(List<ComplaintView> comp)
        {
            tblComplaint.ItemsSource = comp;
            tblActiveComplaint.ItemsSource = comp.Where(c => c.StatusId == 2);
            tblCompleteComplaint.ItemsSource = comp.Where(c => c.StatusId == 3);
            tb.Text = comp.Where(c => c.StatusId == 3).Sum(c => c.expenses).ToString("C");

            tblFailComplaint.ItemsSource = CreateList(comp.Where(c => c.StatusId == 1).ToList());
        }

        private void dpTo_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DatePeriod();
        }

        private void btnBack_click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            DatePeriod();
        }

        private void tblComplaint_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataGrid tbComp = sender as DataGrid;
            ComplaintView comp = new ComplaintView();
            if (tbComp.SelectedItem is ComplaintView)
                comp = tbComp.SelectedItem as ComplaintView;
            else comp = (tbComp.SelectedItem as Helper).ToComplaintView();

            wTask.comp = comp;
            wTask window = new wTask();
            window.ShowDialog();
            DatePeriod();
        }


        public class Helper
        {
            public int ComplaintId { get; set; }
            public string description { get; set; }
            public string note { get; set; }
            public string title { get; set; }
            public int InitiatoriId { get; set; }
            public DateTime filing_date { get; set; }
            public int daysToComplete { get; set; }
            public DateTime? complete_date { get; set; }
            public double expenses { get; set; }
            public string ImportanceTitle { get; set; }
            public int ImportanceId { get; set; }
            public int StatusId { get; set; }
            public string StatusTitle { get; set; }
            public bool isArchived { get; set; }
            public int? Failed { get; set; }

            public ComplaintView ToComplaintView()
            {
                return new ComplaintView
                {
                    ComplaintId = this.ComplaintId,
                    description = this.description,
                    note = this.note,
                    title = this.title,
                    InitiatoriId = this.InitiatoriId,
                    filing_date = this.filing_date,
                    daysToComplete = this.daysToComplete,
                    complete_date = this.complete_date,
                    expenses = this.expenses,
                    ImportanceTitle = this.ImportanceTitle,
                    ImportanceId = this.ImportanceId,
                    StatusId = this.StatusId,
                    StatusTitle = this.StatusTitle,
                    isArchived = this.isArchived
                };
            }

        }
        public List<Helper> CreateList(List<ComplaintView> comp)
        {
            List<Helper> help = new List<Helper>();
            foreach (ComplaintView cmp in comp)
            {
                help.Add(new Helper
                {
                    ComplaintId = cmp.ComplaintId,
                    description = cmp.description,
                    note = cmp.note,
                    title = cmp.title,
                    InitiatoriId = cmp.InitiatoriId,
                    filing_date = cmp.filing_date,
                    daysToComplete = cmp.daysToComplete,
                    complete_date = cmp.complete_date,
                    expenses = cmp.expenses,
                    ImportanceTitle = cmp.ImportanceTitle,
                    ImportanceId = cmp.ImportanceId,
                    StatusId = cmp.StatusId,
                    StatusTitle = cmp.StatusTitle,
                    isArchived = cmp.isArchived,
                    Failed = (int?)(DateTime.Today - cmp.filing_date.AddDays(cmp.daysToComplete)).Days
                });
            }
            return help;
        }
    }
}
