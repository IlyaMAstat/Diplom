﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TransmashDesktop.Scripts;
using Task = TransmashDesktop.Scripts.Task;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для wNewTask.xaml
    /// </summary>
    public partial class wNewTask : Window
    {
        public static ComplaintView comp { get; set; }
        public wNewTask()
        {
            InitializeComponent();
            if (comp.ComplaintId != 1)
                Title += $" для жалобы №{comp.ComplaintId}";
            else
                Title += " для общих задач";
            cbPerf.ItemsSource = ConnectHelper.entObj.Performer.ToList();
            cbPerf.DisplayMemberPath = "fio";
            cbName.ItemsSource = ConnectHelper.entObj.Task.ToList();
            cbName.DisplayMemberPath = "title";
            tbStart.Text = DateTime.Today.ToString("dd.MM.yyyy");
        }

        public bool CanSave()
        {
            bool t = true;
            if ((cbName.Text.Length < 5 || cbName.Text.Length > 100) && cbName.SelectedItem == null)
            {
                t = t & false;
                cbName.ToolTip = "Название задачи должно содержать от 5 до 100 символов";
                erName.ToolTip = "Название задачи должно содержать от 5 до 100 символов";
                erName.Visibility = Visibility.Visible;
            }
            else
            {
                t = t & true;
                cbName.ToolTip = null;
                erName.ToolTip = null;
                erName.Visibility = Visibility.Hidden;
            }
            if ((cbPerf.Text.Length < 3 || cbPerf.Text.Length > 100) && cbPerf.SelectedItem == null)
            {
                t = t & false;
                cbPerf.ToolTip = "Поле Исполнителя должно содержать от 3 до 100 символов";
                erPerf.ToolTip = "Поле Исполнителя должно содержать от 3 до 100 символов";
                erPerf.Visibility = Visibility.Visible;
            }
            else
            {
                t = t & true;
                cbPerf.ToolTip = null;
                erPerf.ToolTip = null;
                erPerf.Visibility = Visibility.Hidden;
            }
            return t;
        }

        private void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }
        private void cb_KeyUp(object sender, KeyEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }


        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Performer per = new Performer();
            if (cbPerf.SelectedItem != null)
                per = cbPerf.SelectedItem as Performer;
            else
            {
                try
                {
                    if (MessageBox.Show($"Введенный вами исполнитель будет добавлен в БД\nХотите ли вы сохранить исполнителя: {cbPerf.Text} ?", "Сохранение Исполнителя", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        per = new Performer { fio = cbPerf.Text };
                        ConnectHelper.entObj.Performer.Add(per);
                        ConnectHelper.entObj.SaveChanges();
                    }
                    else
                    {
                        cbPerf.Focus();
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла непредвиденная ошибка в сохранении, проверьте данные и повторите попытку\nВызвано исключением:\n{ex}",
                    "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            Task tas = new Task();
            if (cbName.SelectedItem != null)
                tas = cbName.SelectedItem as Task;
            else
            {
                try
                {
                    tas = new Task { title = cbName.Text };
                    ConnectHelper.entObj.Task.Add(tas);
                    ConnectHelper.entObj.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла непредвиденная ошибка в сохранении, проверьте данные и повторите попытку\nВызвано исключением:\n{ex}",
                    "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            try
            {
                CompTask compTask = new CompTask
                {
                    ComplaintId = (int)comp.ComplaintId,
                    TaskId = tas.id,
                    PerformerId = per.id,
                    start_date = DateTime.Today
                };
                ConnectHelper.entObj.CompTask.Add(compTask);
                ConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Задача добавлена!", "Успешное сохранение", MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Пожалуйста проверьте данные на правильность\nВызвано исключением:\n{ex}", "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
