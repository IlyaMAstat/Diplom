﻿using System;
using System.Linq;
using System.Windows;
using TransmashDesktop.Pages;
using TransmashDesktop.Scripts;

namespace TransmashDesktop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.entObj = new TransmashDBEntities();

            foreach (Complaint c in ConnectHelper.entObj.Complaint.Where(c => c.StatusId != 3))
            {
                if (c.filing_date.AddDays(c.daysToComplete) > DateTime.Today)
                    c.StatusId = 2;
                else c.StatusId = 1;
            }
            ConnectHelper.entObj.SaveChanges();
            FrameApp.frmObj = frmMain;
           if( new wLogin().ShowDialog()==false)
                Close();
            else FrameApp.frmObj.Navigate(new pMain());
        }
    }
}
