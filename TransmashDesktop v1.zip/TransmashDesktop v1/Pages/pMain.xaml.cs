﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для pMain.xaml
    /// </summary>
    public partial class pMain : Page
    {
        public pMain()
        {
            InitializeComponent();
            LoadDB();
        }
        public void LoadDB()
        {
            tblComplaint.ItemsSource = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && !c.isArchived && !c.isArchived).OrderBy(c => c.StatusId).ToList();
            tbSearch.Text = "";
            cbFilter.SelectedIndex = 0;
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            FiltSearch();
        }
        private void cbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FiltSearch();
        }

        private void FiltSearch()
        {
            switch (cbFilter.SelectedIndex)
            {
                case 0:
                    tblComplaint.ItemsSource = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && !c.isArchived && c.description.Contains(tbSearch.Text)).OrderBy(c => c.StatusId).ToList();
                    break;
                case 1:
                    tblComplaint.ItemsSource = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && !c.isArchived && c.description.Contains(tbSearch.Text) && c.StatusId != 3).OrderBy(c => c.StatusId).ToList();
                    break;
                case 2:
                    tblComplaint.ItemsSource = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && !c.isArchived && c.description.Contains(tbSearch.Text) && c.StatusId == 3).OrderBy(c => c.StatusId).ToList();
                    break;
                case 3:
                    tblComplaint.ItemsSource = ConnectHelper.entObj.ComplaintView.Where(c => c.ComplaintId != 1 && c.isArchived && c.description.Contains(tbSearch.Text)).OrderBy(c => c.StatusId).ToList();
                    break;
            }
        }

        private void btnBack_click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Content = null;
            Window main = (FrameApp.frmObj.Parent as Grid).Parent as Window;
            main.Hide();
            if (new wLogin().ShowDialog() == false)
                main.Close();
            else
            { main.Show();
                FrameApp.frmObj.Navigate(new pMain());
            }
        }

        private void btnArchive_Click(object sender, RoutedEventArgs e)
        {
            int id = (int)(tblComplaint.SelectedItem as ComplaintView).ComplaintId;
            ConnectHelper.entObj.Complaint.First(c => c.id == id).isArchived = true;
            ConnectHelper.entObj.SaveChanges();
            FiltSearch();
        }

        private void newComplaint_Click(object sender, RoutedEventArgs e)
        {
            new wNewComplaint().ShowDialog();
            LoadDB();
        }

        private void ListPerformer_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new pPerformersStatistic());
        }

        private void ComplaintsStatistic_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new pPeriodStatistic());
        }

        private void tblComplaint_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!(tblComplaint.SelectedItem is ComplaintView))
                return;
            wTask.comp = tblComplaint.SelectedItem as ComplaintView;
            wTask window = new wTask();
            window.ShowDialog();
            FiltSearch();
        }

    }
}
