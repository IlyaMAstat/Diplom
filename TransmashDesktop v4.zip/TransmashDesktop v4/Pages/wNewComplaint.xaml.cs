﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для wNewComplaint.xaml
    /// </summary>
    public partial class wNewComplaint : Window
    {
        public wNewComplaint()
        {
            InitializeComponent();
            tbStart.Text = DateTime.Today.ToString("dd.MM.yyyy");
            cbFrom.ItemsSource = ConnectHelper.entObj.Initiator.ToList();
            cbFrom.DisplayMemberPath = "title";
            tbDaysComplete.Text = "7";
            cbImport.SelectedIndex = 0;
        }

        public bool CanSave()
        {
            bool t = true;
            if (tbCode.Text.Length < 1 || !int.TryParse(tbCode.Text, out int _))
            {
                t = t & false;
                erCode.Visibility = Visibility.Visible;
                tbCode.ToolTip = "Поле \"Номер документа\" должно иметь целое число";
                erCode.ToolTip = "Поле \"Номер документа\" должно иметь целое число";
            }
            else
            {
                t = t & true;
                tbCode.ToolTip = null;
                erCode.ToolTip = null;
                erCode.Visibility = Visibility.Hidden;
            }
            if ((tbName.Text.Length < 5 || tbName.Text.Length > 100))
            {
                t = t & false;
                tbName.ToolTip = "Жалоба должна содержать от 5 до 100 символов";
                erName.ToolTip = "Жалоба должна содержать от 5 до 100 символов";
                erName.Visibility = Visibility.Visible;
            }
            else
            {
                t = t & true;
                tbName.ToolTip = null;
                erName.ToolTip = null;
                erName.Visibility = Visibility.Hidden;
            }
            if ((cbFrom.Text.Length < 1 || cbFrom.Text.Length > 100) && cbFrom.SelectedItem == null)
            {
                t = t & false;
                erFrom.Visibility = Visibility.Visible;
                cbFrom.ToolTip = "Поле Инициатора не должно быть пустым и превышать 100 символов";
                erFrom.ToolTip = "Поле Инициатора не должно быть пустым и превышать 100 символов";
            }
            else
            {
                t = t & true;
                erFrom.Visibility = Visibility.Hidden;
                cbFrom.ToolTip = null;
                erFrom.ToolTip = null;
            }
            if (tbDaysComplete.Text.Length < 1 || !int.TryParse(tbDaysComplete.Text, out int daysTo) || daysTo > 366 || daysTo < 1)
            {
                t = t & false;
                erDays.Visibility = Visibility.Visible;
                tbDaysComplete.ToolTip = "Поле \"Дней на выполнение\" должно иметь целое число дней не больше года";
                erDays.ToolTip = "Поле \"Дней на выполнение\" должно иметь целое число дней не больше года";
                tbDead.Text = "";
            }
            else
            {
                t = t & true;
                erDays.Visibility = Visibility.Hidden;
                tbDaysComplete.ToolTip = null;
                erDays.ToolTip = null;
                tbDead.Text = DateTime.Today.AddDays(int.Parse(tbDaysComplete.Text)).ToString("dd.MM.yyyy");
            }
            return t;
        }

        private void tbDaysComplete_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }

        private void cbImport_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }

        private void cbFrom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }

        private void tbTextChanged(object sender, TextChangedEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }

        private void cbFrom_KeyUp(object sender, KeyEventArgs e)
        {
            if (CanSave()) btnSave.IsEnabled = true;
            else btnSave.IsEnabled = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Initiator ini = new Initiator();
            if (cbFrom.SelectedItem != null)
                ini = cbFrom.SelectedItem as Initiator;
            else
            {
                try
                {
                    if (MessageBox.Show($"Введенный вами инициатор будет добавлен в БД\nХотите ли вы сохранить: {cbFrom.Text}",
                        "Сохранение Инициатора", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        ini = new Initiator { title = cbFrom.Text };
                        ConnectHelper.entObj.Initiator.Add(ini);
                        ConnectHelper.entObj.SaveChanges();
                    }
                    else
                    {
                        cbFrom.Focus();
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла непредвиденная ошибка в сохранении, " +
                        $"проверьте данные и повторите попытку\nВызвано исключением:\n{ex}",
                        "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            try
            {
                Complaint complaint = new Complaint
                {
                    description = tbName.Text,
                    note = "",
                    ImportanceId = cbImport.SelectedIndex + 1,
                    InitiatoriId = ini.id,
                    StatusId = 2,
                    filing_date = DateTime.Today,
                    daysToComplete = int.Parse(tbDaysComplete.Text),
                    sourceDoc = int.Parse(tbCode.Text)
                };
                ConnectHelper.entObj.Complaint.Add(complaint);
                ConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Претензия зарегистрирована!", "Успешное сохранение",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Пожалуйста проверьте данные на правильность\nВызвано исключением:\n{ex}",
                    "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
