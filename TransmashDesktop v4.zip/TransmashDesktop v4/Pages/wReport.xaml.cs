﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для wReport.xaml
    /// </summary>
    public partial class wReport : Window
    {
        public static ComplaintView comp { get; set; }
        public static List<TaskView> tasks { get; set; }
        public wReport()
        {
            InitializeComponent();
            Title = $"Отчет по претензии №{comp.ComplaintId}";
            lb.Text = $"\nпо претензии №{comp.ComplaintId}\n";
            lb1.Text = $"От {comp.filing_date.ToString("dd.MM.yyyy")} была зарегистрирована претензия «{comp.description}» " +
            $"от заявителя {comp.title}, она получила {comp.ImportanceTitle.Replace("ая", "ую")} важность.";
            int i = 1;
            foreach (TaskView task in tasks)
            {
                lb3.Text += $"{i}.   Задача «{task.title}» была создана {task.start_date.ToString("dd.MM.yyyy")}, " +
                    $"на ее исполнение был назначен {task.fio}, затраты на задачу составили {task.expenses.ToString("C")} " +
                    $"Задача была завершена {((DateTime)task.end_date).ToString("dd.MM.yyyy")}\n";
                i++;
            }
            lb4.Text = $"Претензия была закрыта {((DateTime)comp.complete_date).ToString("dd.MM.yyyy")}.";
            lb5.Text = $"По итогам всех работ на претензию было потрачено {comp.expenses.ToString("C")}";
            if (comp.note.Length > 1)
                lb6.Text = "Претензия имеет заметки:\n" +
                    $"\t{comp.note}";
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            double w = spReport.Width;
            double h = spReport.Height;
            double ww = Width;
            double hw = Height;
            const double pixelsInCentimeter = 96 / 2.54;
            PrintDialog printDialog = new PrintDialog();
            spReport.Height = 30 * pixelsInCentimeter;
            spReport.Width = 21 * pixelsInCentimeter;
            spHelp.Margin = new Thickness(3 * pixelsInCentimeter, 2 * pixelsInCentimeter, 1.5 * pixelsInCentimeter, 2 * pixelsInCentimeter);
            Height = 30 * pixelsInCentimeter + 10;
            Width = 21 * pixelsInCentimeter + 10;
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(spReport, "Результирующий отчет по жалобе №" + comp.ComplaintId);
            }
            spHelp.Margin = new Thickness(30, 0, 30, 0);
            spReport.Height = h;
            spReport.Width = w;
            Height = hw;
            Width = ww;
        }
    }
}