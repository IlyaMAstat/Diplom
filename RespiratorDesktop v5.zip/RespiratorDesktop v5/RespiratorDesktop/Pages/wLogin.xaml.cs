﻿using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using RespiratorDesktop.Scripts;

namespace RespiratorDesktop.Pages
{
 /// <summary>
 /// Логика взаимодействия для wLogin.xaml
 /// </summary>
 public partial class wLogin : Window
 {
  public static bool cl;
  public wLogin()
  {
   InitializeComponent();
   tbLogin.Text = "Введите логин";
   tbLogin.Foreground = Brushes.Gray;
   cl = false;
  }
  private void tbLogin_GotFocus(object sender, RoutedEventArgs e)
  {
   if (tbLogin.Text == "Введите логин")
   {
    tbLogin.Text = null;
    tbLogin.Foreground = Brushes.Black;
   }
  }

  private void tbLogin_LostFocus(object sender, RoutedEventArgs e)
  {
   if (tbLogin.Text.Length < 1)
   {
    tbLogin.Text = "Введите логин";
    tbLogin.Foreground = Brushes.Gray;
   }
  }

  private void btnReg_Click(object sender, RoutedEventArgs e)
  {
   new wRegistrarion().ShowDialog();
   cl = false;
  }

  private void btnSignin_Click(object sender, RoutedEventArgs e)
  {
   if (tbLogin.Text.Length < 1 || tbLogin.Text == "Введите логин")
   {
    MessageBox.Show("Не введен логин", "Ошибка входа",
     MessageBoxButton.OK, MessageBoxImage.Warning);
    tbLogin.Focus();
    return;
   }
   if (psb.Password.Length < 1)
   {
    MessageBox.Show("Не введен пароль", "Ошибка входа",
     MessageBoxButton.OK, MessageBoxImage.Warning);
    psb.Focus();
    return;
   }
   if (ConnectHelper.entObj.User.
    Count(x => x.login == tbLogin.Text && x.password == psb.Password) == 1)
   {
    cl = true;
    Close();
   }
   else
   {
    MessageBox.Show("Неверный логин или пароль", "Ошибка входа",
     MessageBoxButton.OK, MessageBoxImage.Warning);
   }
  }

  private void tbLogin_KeyUp(object sender, KeyEventArgs e)
  {
   if (e.Key != Key.Enter)
    return;
   if (sender == tbLogin)
    psb.Focus();
   if (sender == psb)
    btnSignin_Click(sender, e);
  }


 }
}
