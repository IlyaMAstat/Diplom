﻿using System.Windows;
using System.Windows.Controls;
using RespiratorDesktop.Scripts;

namespace RespiratorDesktop.Pages
{
 /// <summary>
 /// Логика взаимодействия для wExpenses.xaml
 /// </summary>
 public partial class wExpenses : Window
 {
  public static CompTask task { get; set; }
  public wExpenses()
  {
   InitializeComponent();
   tbExpenses.Text = "0";
  }

  private void tbExpenses_TextChanged(object sender, TextChangedEventArgs e)
  {
   if (float.TryParse(tbExpenses.Text, out float exp))
    btnOk.IsEnabled = true;
   else btnOk.IsEnabled = false;
  }

  private void btnOk_Click(object sender, RoutedEventArgs e)
  {
   if (float.TryParse(tbExpenses.Text, out float exp))
   {
    task.expenses = exp;
    ConnectHelper.entObj.SaveChanges();
    DialogResult = true;
   }
   else
   {
    MessageBox.Show("Введено некоректное число", "Неверный формат числа", MessageBoxButton.OK, MessageBoxImage.Error);
   }
  }
 }
}
