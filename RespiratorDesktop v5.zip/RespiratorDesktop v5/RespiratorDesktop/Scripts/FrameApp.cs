﻿using System.Windows.Controls;

namespace RespiratorDesktop.Scripts
{
 class FrameApp
 {
  public static Frame frmObj;
 }
}
