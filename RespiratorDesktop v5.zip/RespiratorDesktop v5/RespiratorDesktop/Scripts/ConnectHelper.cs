﻿namespace RespiratorDesktop.Scripts
{
 class ConnectHelper
 {
  public static RespiratorDBEntities entObj;
 }
}
