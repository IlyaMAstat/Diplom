﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
    /// <summary>
    /// Логика взаимодействия для wRegistrarion.xaml
    /// </summary>
    public partial class wRegistrarion : Window
    {
        public wRegistrarion()
        {
            InitializeComponent();
        }
        private void psb_PasswordChanged(object sender, RoutedEventArgs e)
        {
            bool t = true;
            if (psb.Password.Length < 6)
            {
                psb.ToolTip = "Пароль должит иметь 6 и более символов";
                psb.Background = Brushes.LightCoral;
                t = false & t;
            }
            else
            {
                psb.ToolTip = null;
                psb.Background = Brushes.LightGreen;
                t = true & t;
            }
            if (psbpov.Password != psb.Password)
            {
                psbpov.ToolTip = "Пароли должны совпадать";
                psbpov.Background = Brushes.LightCoral;
                t = false & t;
            }
            else
            {
                psbpov.ToolTip = null;
                psbpov.Background = Brushes.LightGreen;
                t = true & t;
            }
            if (tbLogin.Text.Length < 4)
            {
                tbLogin.ToolTip = "Логин должен иметь длину 4 и более символов";
                tbLogin.Background = Brushes.LightCoral;
                t = false & t;
            }
            else
            {
                if (ConnectHelper.entObj.User.Count(x => x.login == tbLogin.Text) > 0)
                {
                    tbLogin.ToolTip = "Такой логин уже занят";
                    tbLogin.Background = Brushes.LightCoral;
                    t = false & t;
                }
                else
                {
                    tbLogin.ToolTip = null;
                    tbLogin.Background = Brushes.LightGreen;
                    t = true & t;
                }
            }
            if (tbFIO.Text.Length < 4)
            {
                tbFIO.ToolTip = "ФИО должно иметь длину 4 и более символов";
                tbFIO.Background = Brushes.LightCoral;
                t = false & t;
            }
            else
            {
                tbFIO.ToolTip = null;
                tbFIO.Background = Brushes.LightGreen;
                t = true & t;
            }
            if (t)
                btnReg.IsEnabled = true;
            else btnReg.IsEnabled = false;
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                User userObj = new User()
                {
                    login = tbLogin.Text,
                    password = psb.Password,
                    fio = tbFIO.Text
                };
                ConnectHelper.entObj.User.Add(userObj);
                ConnectHelper.entObj.SaveChanges();
                MessageBox.Show($"Пользователь '{userObj.login}' создан!", "Новый пользователь",
                MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult=true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Что-то произошло", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void tbLogin_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter)
                return;
            if (sender == tbFIO)
                tbLogin.Focus();
            if (sender == tbLogin)
                psb.Focus();
            if (sender == psb)
                psbpov.Focus();
        }
    }
}
