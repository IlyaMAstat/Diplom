﻿namespace TransmashDesktop.Scripts
{
    class ConnectHelper
    {
        public static TransmashDBEntities entObj;
    }
}
