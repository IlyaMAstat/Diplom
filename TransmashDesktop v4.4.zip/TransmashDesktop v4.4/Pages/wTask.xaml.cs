﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
 /// <summary>
 /// Логика взаимодействия для wTask.xaml
 /// </summary>
 public partial class wTask : Window
 {
  public static ComplaintView comp { get; set; }
  public static List<TaskView> task { get; set; }
  public wTask()
  {
   InitializeComponent();
   Title = "Жалоба №" + comp.ComplaintId;
   Update();

  }

  private void Update()
  {
   comp = ConnectHelper.entObj.ComplaintView.First(c => c.ComplaintId == comp.ComplaintId);
   task = ConnectHelper.entObj.TaskView.Where(t => t.ComplaintId == comp.ComplaintId).ToList();
   tblTask.ItemsSource = task;
   tblTemplate.ItemsSource = ConnectHelper.entObj.TaskView.Where(t => t.ComplaintId == 1).ToList();
   tbName.Text = comp.description;
   tbNote.Text = comp.note;
   tbCod.Text = comp.sourceDoc.ToString();
   tbStart.Text = comp.filing_date.ToShortDateString();
   if (comp.complete_date != null)
   {
    btnNewTask.Visibility = Visibility.Collapsed;
    btnReport.Visibility = Visibility.Visible;
    btnSave.Visibility = Visibility.Collapsed;
    btnFinish.Visibility = Visibility.Collapsed;
    tbEnd.Text = ((DateTime)comp.complete_date).ToShortDateString();
    (tcTask.Items[0] as TabItem).Header = "Задачи";
    (tcTask.Items[1] as TabItem).Visibility = Visibility.Collapsed;
    tbNote.IsEnabled = false;
    tbInitiator.IsEnabled = false;
   }
   else
   {
    btnNewTask.Visibility = Visibility.Visible;
    btnReport.Visibility = Visibility.Collapsed;
    btnSave.Visibility = Visibility.Visible;
    btnFinish.Visibility = Visibility.Visible;
    (tcTask.Items[0] as TabItem).Header = "Текущие Задачи";
    (tcTask.Items[1] as TabItem).Visibility = Visibility.Visible;
    tbNote.IsEnabled = true;
    tbInitiator.IsEnabled = true;
    if ((task.Count > 0 && task.All(t => t.end_date != null)) || (task.Count < 1 && comp.note.Length > 0))
     btnFinish.IsEnabled = true;
    else
     btnFinish.IsEnabled = false;
   }
   tbExtences.Text = comp.expenses.ToString("C");
   tbDead.Text = comp.filing_date.AddDays(comp.daysToComplete).ToShortDateString();
   tbInitiator.Text = comp.title;
   cbImport.SelectedIndex = comp.ImportanceId - 1;
   if (CanSave()) btnSave.IsEnabled = true;
   else btnSave.IsEnabled = false;
  }

  private void btnSave_Click(object sender, RoutedEventArgs e)
  {
   Complaint complaint = ConnectHelper.entObj.Complaint.First(c => c.id == comp.ComplaintId);
   complaint.note = tbNote.Text;
   complaint.ImportanceId = cbImport.SelectedIndex + 1;
   ConnectHelper.entObj.SaveChanges();
   MessageBox.Show("Претензия обновлена!", "Успешное сохранение", MessageBoxButton.OK, MessageBoxImage.Information);
   Update();
  }

  private void btnFinish_Click(object sender, RoutedEventArgs e)
  {
   Complaint complaint = ConnectHelper.entObj.Complaint.First(c => c.id == comp.ComplaintId);
   if (MessageBox.Show("Хотите завершить проект?", "Завершение проекта", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
    return;
   else
   {
    try
    {
     complaint.StatusId = 3;
     complaint.complete_date = DateTime.Today;
     ConnectHelper.entObj.SaveChanges();
     MessageBox.Show("Жалоба закрыта!", "Успешное завершение", MessageBoxButton.OK, MessageBoxImage.Information);
     Update();
    }
    catch (Exception ex)
    {
     MessageBox.Show($"Произошла непредвиденная ошибка в сохранении\nВызвано исключением:\n{ex}",
      "Ошибка завершения", MessageBoxButton.OK, MessageBoxImage.Error);
     return;
    }
   }
  }

  private void btnReport_Click(object sender, RoutedEventArgs e)
  {
   wReport.comp = comp;
   wReport.tasks = task;
   new wReport().ShowDialog();
  }

  private void btnNewTask_Click(object sender, RoutedEventArgs e)
  {
   if (tcTask.SelectedIndex == 1)
    wNewTask.comp = ConnectHelper.entObj.ComplaintView.First(c => c.ComplaintId == 1);
   else wNewTask.comp = comp;
   new wNewTask().ShowDialog();
   Update();
  }

  private void btnAdd_Click(object sender, RoutedEventArgs e)
  {
   TaskView cmptask = tblTemplate.SelectedItem as TaskView;
   if (task.Select(t => t.TaskId).Contains(cmptask.TaskId))
   {
    MessageBox.Show("Невозможно добавить задачу, которая выполняется в данный момент или выполнялась раньше", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    return;
   }
   if (MessageBox.Show("Хотите добавить данную задачу к вашему проекту?", "Добавление из шаблона", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
   {
    CompTask compTask = new CompTask
    {
     ComplaintId = (int)comp.ComplaintId,
     TaskId = cmptask.TaskId,
     PerformerId = cmptask.PerformerId,
     start_date = DateTime.Today
    };
    ConnectHelper.entObj.CompTask.Add(compTask);
    ConnectHelper.entObj.SaveChanges();
   }
   Update();
  }

  private void btnClose_Click(object sender, RoutedEventArgs e)
  {
   int comptaskid = (tblTask.SelectedItem as TaskView).id;
   CompTask task = ConnectHelper.entObj.CompTask.Where(c => c.id == comptaskid).FirstOrDefault();
   if (task == null)
   {
    MessageBox.Show("Выбранной задачи не существует", "Ошибка закрытия", MessageBoxButton.OK, MessageBoxImage.Error);
    return;
   }
   wExpenses.task = task;
   if (new wExpenses().ShowDialog() == true)
   {
    task.end_date = DateTime.Today;
    ConnectHelper.entObj.SaveChanges();
   }
   Update();
  }

  public bool CanSave()
  {
   bool t = false;
   if (tbNote.Text != comp.note)
    t = t || true;
   if (cbImport.SelectedItem != null)
    if (cbImport.SelectedIndex + 1 != comp.ImportanceId)
     t = t || true;
   return t;
  }

  private void tb_TextChanged(object sender, TextChangedEventArgs e)
  {
   if (CanSave()) btnSave.IsEnabled = true;
   else btnSave.IsEnabled = false;
  }

  private void cbImport_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
   if (CanSave()) btnSave.IsEnabled = true;
   else btnSave.IsEnabled = false;
  }
 }
}
