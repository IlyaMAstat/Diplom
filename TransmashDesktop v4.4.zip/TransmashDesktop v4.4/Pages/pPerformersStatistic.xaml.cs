﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using TransmashDesktop.Scripts;

namespace TransmashDesktop.Pages
{
 /// <summary>
 /// Логика взаимодействия для pPerformersStatistic.xaml
 /// </summary>
 public partial class pPerformersStatistic : Page
 {
  public pPerformersStatistic()
  {
   InitializeComponent();
   lbPerf.DisplayMemberPath = "fio";
   List<Performer> performers = ConnectHelper.entObj.Performer.ToList();
   performers.ForEach(a => a.fio = a.fio.Replace(", ", "\n"));
   
   lbPerf.ItemsSource =  performers;
   
  }

  private void btnBack_click(object sender, RoutedEventArgs e)
  {
   FrameApp.frmObj.GoBack();
  }

  private void lbPerf_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
   if (lbPerf.SelectedItem == null)
    return;
   int si = (lbPerf.SelectedItem as Performer).id;
   tblCompleteTask.ItemsSource = ConnectHelper.entObj.TaskView.Where(t => t.PerformerId == si && t.end_date != null && t.ComplaintId != 1).ToList();
   tblActiveTask.ItemsSource = ConnectHelper.entObj.TaskView.Where(t => t.PerformerId == si && t.end_date == null && t.ComplaintId != 1).ToList();
  }
 }
}
