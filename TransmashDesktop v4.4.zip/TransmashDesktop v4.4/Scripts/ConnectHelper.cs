﻿namespace TransmashDesktop.Scripts
{
 class ConnectHelper
 {
  public static RespiratorDBEntities entObj;
 }
}
