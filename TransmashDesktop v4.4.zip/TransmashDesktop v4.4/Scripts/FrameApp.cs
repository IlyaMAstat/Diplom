﻿using System.Windows.Controls;

namespace TransmashDesktop.Scripts
{
 class FrameApp
 {
  public static Frame frmObj;
 }
}
